MB Tray Control
version 1.0
Copyright 2000 by Marco Bellinaso


NOTE:
Tray ActiveX requires the runtime DLL for Visual Basic 6 (msvbvm60.dll).
If you are using an older VB version, you can download the runtine on Microsoft web site at
http://support.microsoft.com/download/support/mslfiles/Vbrun60.exe
See the About Box for more information.


CONTACT INFORMATION:
You can contact the author at mbellinaso@vb2themax.com
Download the latest version of the control on www.vb2themax.com